import { Readable } from 'node:stream';
import {
  assertAgentClientAccess,
  assertAgentCountryAccess,
  authenticateAgentRequest,
  getSupabaseAdminConfig,
  respondAuthError,
  supabaseRestRequest,
} from '../supabaseAuth.js';
import {
  createPbxAudioTicket,
  fetchPbxCallsRange,
  fetchPbxRecording,
  getPbxCallAgentMatch,
  getPbxUsernameFromEmail,
  isPbxDateRangeAllowed,
  parsePbxCallDateTime,
  parsePbxDateTimeLocal,
  pbxPhoneDigits,
  pbxPhonesMatch,
  verifyPbxAudioTicket,
} from '../pbx.js';

type Country = 'SV' | 'GT';

function queryText(value: unknown): string {
  return Array.isArray(value) ? String(value[0] || '').trim() : String(value || '').trim();
}

export async function listPbxCallsHandler(req: any, res: any) {
  res.setHeader('Cache-Control', 'private, no-store');
  if (String(req.method || '').toUpperCase() !== 'GET') {
    res.setHeader('Allow', 'GET');
    return res.status(405).json({ success: false, error: 'METHOD_NOT_ALLOWED' });
  }

  try {
    const context = await authenticateAgentRequest(req);
    const country = context.agent.pais as Country;
    assertAgentCountryAccess(context, country);

    const requestedCountry = queryText(req.query?.pais).toUpperCase();
    if (requestedCountry && requestedCountry !== country) {
      return res.status(403).json({ success: false, error: 'COUNTRY_ACCESS_DENIED' });
    }
    const fallbackDate = queryText(req.query?.fecha);
    const fromDate = queryText(req.query?.desde) || fallbackDate;
    const toDate = queryText(req.query?.hasta) || fallbackDate;
    const fromDateTimeValue = queryText(req.query?.hora_desde) || `${fromDate}T00:00`;
    const toDateTimeValue = queryText(req.query?.hora_hasta) || `${toDate}T23:59`;
    const fromDateTime = parsePbxDateTimeLocal(fromDateTimeValue);
    const toDateTime = parsePbxDateTimeLocal(toDateTimeValue);
    if (
      !isPbxDateRangeAllowed(fromDate, toDate)
      || !fromDateTime
      || !toDateTime
      || fromDateTimeValue.slice(0, 10) !== fromDate
      || toDateTimeValue.slice(0, 10) !== toDate
      || fromDateTime.getTime() > toDateTime.getTime()
    ) {
      return res.status(400).json({
        success: false,
        error: 'INVALID_CALL_DATE_RANGE',
        message: 'Elige un rango válido dentro de los últimos 7 días, con fecha y hora inicial anterior a la final.',
      });
    }

    const clientCode = queryText(req.query?.codigo_cliente).toUpperCase();
    const destinationPhone = queryText(req.query?.telefono_destino);
    if (!clientCode) {
      return res.status(400).json({ success: false, error: 'CLIENT_REQUIRED' });
    }
    if (pbxPhoneDigits(destinationPhone).length < 8) {
      return res.status(400).json({
        success: false,
        error: 'DESTINATION_PHONE_REQUIRED',
        message: 'Ingresa o selecciona un teléfono de destino válido para buscar la llamada.',
      });
    }
    await assertAgentClientAccess(context, country, clientCode);

    const extension = String(context.agent.extension_pbx || '').trim();
    const username = getPbxUsernameFromEmail(context.agent.email);
    if (!username && !extension) {
      return res.status(409).json({
        success: false,
        error: 'PBX_AGENT_PROFILE_INCOMPLETE',
        message: 'El perfil del agente necesita un correo o una extensión PBX para identificar sus llamadas.',
      });
    }

    const { body: clients } = await supabaseRestRequest(
      `clientes?select=phone1,phone2,celular&codigo=eq.${encodeURIComponent(clientCode)}&pais=eq.${country}&limit=1`,
      {},
      context,
    );
    if (!Array.isArray(clients) || clients.length === 0) {
      return res.status(404).json({ success: false, error: 'CLIENT_NOT_FOUND' });
    }
    const clientPhones = [
      clients[0].phone1,
      clients[0].phone2,
      clients[0].celular,
    ].map((phone) => String(phone || '')).filter(Boolean);

    const calls = await fetchPbxCallsRange(fromDate, toDate, country);
    const phoneAndTimeCalls = calls.filter((call) => {
      const callTime = parsePbxCallDateTime(call.dateTime);
      return Boolean(call.uniqueId)
        && pbxPhonesMatch(call.destination, destinationPhone)
        && Boolean(callTime)
        && callTime!.getTime() >= fromDateTime.getTime()
        && callTime!.getTime() <= toDateTime.getTime() + 59_999;
    });
    const agentCalls = phoneAndTimeCalls.flatMap((call) => {
      const matchedBy = getPbxCallAgentMatch(call, username, extension);
      return matchedBy ? [{ call, matchedBy }] : [];
    });
    const { serviceRoleKey } = context;
    const records = agentCalls.map(({ call, matchedBy }) => {
      const ticket = createPbxAudioTicket({
        agentId: context.agent.id,
        country,
        date: call.callDate,
        extension: call.extension,
        uniqueId: call.uniqueId,
      }, serviceRoleKey);
      const matchesClientPhone = clientPhones.some((phone) =>
        pbxPhonesMatch(call.destination, phone)
      );
      return {
        callId: call.uniqueId,
        extension: call.extension,
        profileExtension: extension,
        extensionMatchesProfile: Boolean(extension && call.extension === extension),
        matchedBy,
        username: call.username,
        callDate: call.callDate,
        dateTime: call.dateTime,
        origin: call.origin,
        destination: call.destination,
        durationSeconds: call.durationSeconds,
        state: call.state,
        recordingFile: call.recordingFile,
        matchesClientPhone,
        matchesSelectedPhone: true,
        audioUrl: `/api/cartera?action=pbx-audio&ticket=${encodeURIComponent(ticket)}`,
      };
    }).sort((left, right) => {
      if (left.matchedBy !== right.matchedBy) {
        return left.matchedBy === 'username' ? -1 : 1;
      }
      if (left.matchesClientPhone !== right.matchesClientPhone) {
        return left.matchesClientPhone ? -1 : 1;
      }
      return right.dateTime.localeCompare(left.dateTime);
    });

    return res.status(200).json({
      success: true,
      pais: country,
      desde: fromDate,
      hasta: toDate,
      hora_desde: fromDateTimeValue,
      hora_hasta: toDateTimeValue,
      telefono_destino: destinationPhone,
      agente: { extension, usuario: username },
      calls: records,
    });
  } catch (error) {
    return respondAuthError(res, error);
  }
}

export async function pbxSavedManagementAudioTicketHandler(req: any, res: any) {
  res.setHeader('Cache-Control', 'private, no-store');
  if (String(req.method || '').toUpperCase() !== 'GET') {
    res.setHeader('Allow', 'GET');
    return res.status(405).json({ success: false, error: 'METHOD_NOT_ALLOWED' });
  }

  try {
    const context = await authenticateAgentRequest(req);
    const managementId = queryText(req.query?.gestion_id);
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(managementId)) {
      return res.status(400).json({ success: false, error: 'INVALID_MANAGEMENT_ID' });
    }

    const params = new URLSearchParams({
      select: 'id,agente_id,valores_dinamicos,clientes!inner(codigo,pais)',
      id: `eq.${managementId}`,
      limit: '1',
    });
    const { body } = await supabaseRestRequest(`bitacora_gestiones?${params.toString()}`, {}, context);
    if (!Array.isArray(body)) {
      throw new Error('PBX_MANAGEMENT_LOOKUP_INVALID');
    }
    const row = body[0];
    if (!row) {
      return res.status(404).json({ success: false, error: 'MANAGEMENT_NOT_FOUND' });
    }

    const client = Array.isArray(row.clientes) ? row.clientes[0] : row.clientes;
    const country = String(client?.pais || '').trim().toUpperCase() as Country;
    const clientCode = String(client?.codigo || '').trim().toUpperCase();
    if (!clientCode || (country !== 'SV' && country !== 'GT')) {
      return res.status(409).json({ success: false, error: 'MANAGEMENT_CLIENT_INVALID' });
    }
    assertAgentCountryAccess(context, country);

    const managementAgentId = String(row.agente_id || '').trim();
    if (!managementAgentId) {
      return res.status(409).json({ success: false, error: 'MANAGEMENT_AGENT_INVALID' });
    }
    if (context.agent.rol !== 'admin' && managementAgentId !== context.agent.id) {
      await assertAgentClientAccess(context, country, clientCode);
    }

    const values = row.valores_dinamicos && typeof row.valores_dinamicos === 'object'
      && !Array.isArray(row.valores_dinamicos)
      ? row.valores_dinamicos as Record<string, unknown>
      : {};
    const pbxCall = values.pbxCall && typeof values.pbxCall === 'object'
      && !Array.isArray(values.pbxCall)
      ? values.pbxCall as Record<string, unknown>
      : {};
    const uniqueId = queryText(pbxCall.uniqueId || pbxCall.uniqueid);
    const extension = queryText(pbxCall.extension);
    const date = queryText(pbxCall.date || pbxCall.callDate).slice(0, 10);
    const parsedDate = new Date(`${date}T00:00:00.000Z`);
    const validDate = /^\d{4}-\d{2}-\d{2}$/.test(date)
      && Number.isFinite(parsedDate.getTime())
      && parsedDate.toISOString().slice(0, 10) === date;
    if (
      !validDate
      || !/^\d{1,12}$/.test(extension)
      || !/^[A-Za-z0-9.-]{1,120}$/.test(uniqueId)
    ) {
      return res.status(409).json({ success: false, error: 'PBX_CALL_NOT_LINKED' });
    }

    const ticket = createPbxAudioTicket({
      agentId: managementAgentId,
      country,
      date,
      extension,
      uniqueId,
    }, context.serviceRoleKey);
    return res.status(200).json({
      success: true,
      callId: uniqueId,
      audioUrl: `/api/cartera?action=pbx-audio&ticket=${encodeURIComponent(ticket)}`,
    });
  } catch (error) {
    return respondAuthError(res, error);
  }
}

export async function pbxAudioHandler(req: any, res: any) {
  res.setHeader('Cache-Control', 'private, no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  if (String(req.method || '').toUpperCase() !== 'GET') {
    res.setHeader('Allow', 'GET');
    return res.status(405).json({ success: false, error: 'METHOD_NOT_ALLOWED' });
  }

  try {
    const { serviceRoleKey } = getSupabaseAdminConfig();
    const ticket = verifyPbxAudioTicket(queryText(req.query?.ticket), serviceRoleKey);
    if (!ticket) {
      return res.status(401).json({ success: false, error: 'AUDIO_TICKET_INVALID_OR_EXPIRED' });
    }

    const range = String(req.headers?.range || '');
    const response = await fetchPbxRecording(ticket, range);
    const contentType = response.headers.get('content-type') || 'audio/wav';
    const contentRange = response.headers.get('content-range');
    const upstreamLength = response.headers.get('content-length');
    res.setHeader('Content-Type', contentType);
    res.setHeader('Accept-Ranges', response.headers.get('accept-ranges') || 'bytes');
    res.setHeader('Content-Disposition', 'inline');
    if (contentRange) res.setHeader('Content-Range', contentRange);

    if (upstreamLength) res.setHeader('Content-Length', upstreamLength);
    if (!response.body) {
      return res.status(502).json({ success: false, error: 'PBX_AUDIO_EMPTY' });
    }
    return Readable.fromWeb(response.body as any).pipe(res.status(response.status));
  } catch (error) {
    return respondAuthError(res, error);
  }
}
