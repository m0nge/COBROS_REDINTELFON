import React, { useMemo, useState } from 'react';
import { AuthUser, Country } from '../types';
import { RedLogo } from './RedLogo';
import {
  BarChart3,
  BriefcaseBusiness,
  Building2,
  ChevronLeft,
  ChevronRight,
  CircleDollarSign,
  CircleUserRound,
  ClipboardList,
  FileText,
  House,
  LogOut,
  Menu,
  MessageSquareText,
  Phone,
  ShieldCheck,
  Sparkles,
  Sun,
  Moon,
  Users,
  Wallet,
} from 'lucide-react';

interface NavbarProps {
  currentUser: AuthUser;
  agentPbxExtension?: string;
  onLogout: () => void;
  currentCountry: Country;
  activeModule: string;
  onNavigate: (moduleId: string) => void;
  onOpenSyncModal: () => void;
  onToggleMotorMora: () => void;
  isMotorMoraVisible: boolean;
  lastSyncTimestamp: string;
  onOpenAgentModal?: () => void;
  agentsCount?: number;
  isLightMode: boolean;
  onToggleTheme: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  agentPbxExtension,
  onLogout,
  currentCountry,
  activeModule,
  onNavigate,
  onOpenSyncModal,
  onToggleMotorMora,
  isMotorMoraVisible,
  onOpenAgentModal,
  agentsCount,
  isLightMode,
  onToggleTheme,
}) => {
  const isAdmin = currentUser.role === 'admin';
  const [isCollapsed, setIsCollapsed] = useState(false);
  const userPbx = currentUser.role === 'agente' ? agentPbxExtension?.trim() : undefined;

  const adminModules = useMemo(
    () => [
      { id: 'inicio', label: 'Dashboard', icon: House },
      { id: 'motor-mora', label: 'Motor', icon: Sparkles },
      { id: 'inteligencia-negocio', label: 'Inteligencia', icon: BarChart3 },
      { id: 'equipo-cobro', label: 'Equipo', icon: Users },
      { id: 'clientes-criticos', label: 'Clientes Críticos', icon: ShieldCheck },
      { id: 'reportes', label: 'Reportes', icon: BriefcaseBusiness },
      { id: 'constructor-bitacora', label: 'Bitácora', icon: FileText },
      { id: 'scripts-mensajes', label: 'Scripts de Mensajes', icon: MessageSquareText },
    ],
    []
  );

  const agentModules = useMemo(
    () => [
      { id: 'inicio', label: 'Inicio / Resumen', icon: House },
      { id: 'mi-cartera', label: 'Mi Cartera', icon: Wallet },
      { id: 'mis-gestiones', label: 'Mis Gestiones', icon: ClipboardList },
      { id: 'lista-gestion', label: 'Lista de Gestión', icon: Users },
      { id: 'acuerdos', label: 'Acuerdos', icon: CircleDollarSign },
      { id: 'no-contactados', label: 'No Contactados', icon: Phone },
      { id: 'reportes', label: 'Reportes', icon: BriefcaseBusiness },
      { id: 'motor-mora', label: 'Motor de Mora', icon: Sparkles },
    ],
    []
  );

  const modules = isAdmin ? adminModules : agentModules;

  return (
    <aside
      className={`sticky top-0 z-40 flex h-screen min-h-screen shrink-0 self-start flex-col overflow-y-auto border-r border-slate-800/80 bg-[#080D1D] px-3 py-4 transition-all duration-300 ${
        isCollapsed ? 'w-[88px]' : 'w-[260px]'
      }`}
    >
      <div className="mb-4 flex items-center justify-between gap-2 border-b border-slate-800/80 pb-4">
        <div className={`flex items-center gap-3 overflow-hidden ${isCollapsed ? 'justify-center w-full' : ''}`}>
          <RedLogo className="h-10 w-10 shrink-0" />
          {!isCollapsed && (
            <div className="min-w-0">
              <div className="text-sm font-bold text-white">Cobranza Inteligente</div>
              <div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-blue-400">SAP ERP</div>
            </div>
          )}
        </div>

        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="hidden rounded-lg border border-slate-800 bg-slate-900/90 p-1.5 text-slate-300 transition-colors hover:border-blue-500/40 hover:text-blue-300 md:inline-flex"
          aria-label={isCollapsed ? 'Expandir menú' : 'Contraer menú'}
        >
          {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </div>

      <div className={`mb-4 rounded-2xl border border-slate-800 bg-slate-900/70 p-3 ${isCollapsed ? 'px-2' : ''}`}>
        <div className={`mb-2 text-[10px] font-semibold uppercase tracking-[0.22em] text-slate-400 ${isCollapsed ? 'hidden' : 'block'}`}>
          País
        </div>

        <div className="flex items-center justify-center gap-2 rounded-xl bg-slate-950 px-2 py-2 text-[11px] font-semibold text-slate-200">
          <span>{currentCountry === 'SV' ? '🇸🇻' : '🇬🇹'}</span>
          {!isCollapsed && <span>{currentCountry === 'SV' ? 'El Salvador' : 'Guatemala'}</span>}
        </div>
      </div>

      <nav className="mt-2 flex-1 space-y-1.5">
        {modules.map(({ id, label, icon: Icon }) => {
          const isActive = activeModule === id || (!activeModule && isAdmin && id === 'inicio') || (!activeModule && !isAdmin && id === 'inicio');

          return (
            <button
              key={id}
              type="button"
              onClick={() => onNavigate(id)}
              className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-blue-600/85 to-indigo-600/80 text-white shadow-lg shadow-blue-500/20'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              } ${isCollapsed ? 'justify-center px-0' : ''}`}
              title={label}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {!isCollapsed && <span className="truncate">{label}</span>}
            </button>
          );
        })}
      </nav>

      <div className="mt-3 border-t border-slate-800/80 pt-3">
        <div className={`mb-3 flex items-center gap-3 ${isCollapsed ? 'justify-center' : ''}`}>
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-slate-700 bg-slate-900/80 text-slate-300">
            <CircleUserRound className="h-6 w-6" aria-hidden="true" />
          </div>
          {!isCollapsed && (
            <div className="min-w-0">
              <div className="truncate text-sm font-semibold text-white">{currentUser.name}</div>
              <div className="text-[10px] text-blue-400 font-semibold">
                {isAdmin ? 'Administrador' : 'Agente de Cobro'}
              </div>
              {!isAdmin && userPbx && (
                <div className="text-[10px] text-slate-400">PBX: {userPbx}</div>
              )}
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={onToggleTheme}
          aria-pressed={isLightMode}
          className={`mb-2 flex w-full items-center gap-3 rounded-xl border border-slate-800 bg-slate-900/80 px-3 py-2.5 text-sm text-slate-300 transition-colors hover:border-blue-500/40 hover:text-blue-300 ${isCollapsed ? 'justify-center px-0' : ''}`}
          title={isLightMode ? 'Cambiar a modo oscuro' : 'Cambiar a modo claro'}
        >
          {isLightMode ? <Moon className="h-4 w-4 shrink-0" /> : <Sun className="h-4 w-4 shrink-0" />}
          {!isCollapsed && <span>{isLightMode ? 'Modo oscuro' : 'Modo claro'}</span>}
        </button>

        <button
          onClick={onLogout}
          className={`flex w-full items-center gap-3 rounded-xl border border-slate-800 bg-slate-900/80 px-3 py-2.5 text-sm text-slate-300 transition-colors hover:border-red-500/40 hover:text-red-300 ${isCollapsed ? 'justify-center px-0' : ''}`}
          title="Cerrar sesión"
        >
          <LogOut className="h-4 w-4 shrink-0" />
          {!isCollapsed && <span>Cerrar sesión</span>}
        </button>
      </div>

      {!isCollapsed && (
        <div className="mt-3 flex items-center justify-center gap-2 rounded-xl border border-slate-800 bg-slate-900/70 p-2 text-[10px] font-medium uppercase tracking-[0.18em] text-slate-400">
          <Menu className="h-3.5 w-3.5" />
          Menú
        </div>
      )}
    </aside>
  );
};
