import React, { useState, useEffect, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { Client, Country, PaymentAgreement, Agent } from '../types';
import { authenticatedApiFetch } from '../services/authService';
import { DateInput } from './DateInput';
import { getElSalvadorDateKey, getElSalvadorDateParts, getRecordDateKey } from '../utils/gestionDates';
import {
  getAgendaEligibilityReadWarning,
  getManagementReadWarning,
  getMonthlyStateReadWarning,
} from '../utils/authoritativeManagement';
import {
  filterAgreementsByVerifiedEligibility,
  getPromiseDisplayStatus,
  isResolvedInOrAfterPromiseMonth,
  latestPromisePerClient,
} from '../utils/latestPromise';
import {
  CircleDollarSign,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Download,
  FileSpreadsheet,
  X,
  ExternalLink,
  ChevronRight,
  Info,
  RefreshCw,
} from 'lucide-react';

interface AcuerdosViewProps {
  currentCountry: Country;
  clients: Client[];
  agents: Agent[];
  currentAgent?: Agent;
  onOpenGestionModal?: (client: Client) => void;
  isAdmin?: boolean;
  onUpdateClientData?: (clientCode: string, updates: Partial<Client>) => void;
  onScheduleFollowUp?: (clientCode: string, targetDate: string, reason?: string) => void;
}

export const AcuerdosView: React.FC<AcuerdosViewProps> = ({
  currentCountry,
  clients,
  agents,
  currentAgent,
  onOpenGestionModal,
  isAdmin = false,
  onScheduleFollowUp,
}) => {
  const [agreements, setAgreements] = useState<PaymentAgreement[]>([]);
  const [agreementReadError, setAgreementReadError] = useState('');
  const [isLoadingAgreements, setIsLoadingAgreements] = useState(true);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'TODOS' | 'Pendiente' | 'Cumplido' | 'Vencido'>('TODOS');
  const [isFulfillModalOpen, setIsFulfillModalOpen] = useState(false);
  const [selectedAgreementForFulfill, setSelectedAgreementForFulfill] = useState<PaymentAgreement | null>(null);
  const [receiptNumber, setReceiptNumber] = useState('');
  const [fulfillNotes, setFulfillNotes] = useState('');
  const [selectedPromiseDate, setSelectedPromiseDate] = useState(getElSalvadorDateKey());
  const [isValidatingPromises, setIsValidatingPromises] = useState(false);
  const [promiseValidationResult, setPromiseValidationResult] = useState('');
  const [followUpDates, setFollowUpDates] = useState<Record<string, string>>({});
  const [unpaidPromises, setUnpaidPromises] = useState<Record<string, string[]>>({});
  const [monthlyResolvedKeys, setMonthlyResolvedKeys] = useState<string[]>([]);
  const [agendaEligibleCodes, setAgendaEligibleCodes] = useState<string[]>([]);
  const [agendaEligibilityLoading, setAgendaEligibilityLoading] = useState(true);
  const [agendaEligibilityError, setAgendaEligibilityError] = useState('');

  // Selected agreement for inspection modal
  const [inspectedAgreement, setInspectedAgreement] = useState<PaymentAgreement | null>(null);

  const todayKey = getElSalvadorDateKey();
  const todayParts = getElSalvadorDateParts();
  const endOfCurrentMonth = `${todayParts.year}-${String(todayParts.month).padStart(2, '0')}-${String(new Date(todayParts.year, todayParts.month, 0).getDate()).padStart(2, '0')}`;

  useEffect(() => {
    let isCurrentCountry = true;
    setMonthlyResolvedKeys([]);
    setAgendaEligibleCodes([]);
    setAgendaEligibilityError('');
    setAgendaEligibilityLoading(true);
    const { year, month } = getElSalvadorDateParts();
    const months = Array.from({ length: 4 }, (_, index) => {
      const date = new Date(Date.UTC(year, month - 1 - index, 1, 12));
      return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`;
    });
    Promise.all(months.map((monthKey) =>
      authenticatedApiFetch(
        `/api/cartera?action=estado-mensual&pais=${encodeURIComponent(currentCountry)}&mes=${monthKey}`,
        { cache: 'no-store' },
      )
    ))
      .then(async (responses) => {
        const stateGroups = await Promise.all(responses.map(async (response) => {
          const payload = await response.json().catch(() => ({}));
          if (!response.ok || !payload.success || !Array.isArray(payload.states)) {
            throw new Error('MONTHLY_STATE_UNAVAILABLE');
          }
          const monthlyStateWarning = getMonthlyStateReadWarning(payload);
          if (monthlyStateWarning) throw new Error(monthlyStateWarning);
          return { payload, states: payload.states as any[] };
        }));
        if (!isCurrentCountry) return;
        setMonthlyResolvedKeys(
          stateGroups.flatMap((group) => group.states).map((state: any) =>
            `${state.pais}:${state.codigo_cliente}:${state.mes_periodo}`
          ),
        );
        const eligibilityWarning = getAgendaEligibilityReadWarning(stateGroups[0]?.payload);
        if (eligibilityWarning) {
          setAgendaEligibilityError('No se pudo confirmar en SAN qué clientes tienen facturas vencidas. Las promesas abiertas no se mostrarán hasta verificar la cartera.');
          setAgendaEligibleCodes([]);
        } else {
          setAgendaEligibleCodes(stateGroups[0].payload.agendaEligibleCodes);
        }
      })
      .catch(() => {
        if (isCurrentCountry) {
          setMonthlyResolvedKeys([]);
          setAgendaEligibleCodes([]);
          setAgendaEligibilityError('No se pudo confirmar en SAN qué clientes tienen facturas vencidas. Las promesas abiertas no se mostrarán hasta verificar la cartera.');
        }
      })
      .finally(() => {
        if (isCurrentCountry) setAgendaEligibilityLoading(false);
      });
    return () => {
      isCurrentCountry = false;
    };
  }, [currentCountry]);

  useEffect(() => {
    let active = true;
    let requestInFlight = false;
    const loadPersistedAgreements = async () => {
      if (requestInFlight) return;
      requestInFlight = true;
      setAgreements([]);
      setAgreementReadError('');
      setIsLoadingAgreements(true);
      try {
        let requests: Promise<Response>[];
        if (isAdmin) {
          requests = [authenticatedApiFetch(
            `/api/admin/agentes?action=gestiones&pais=${encodeURIComponent(currentCountry)}`,
            { cache: 'no-store' },
          )];
        } else {
          if (!currentAgent) throw new Error('Esta cuenta no está vinculada a un agente.');
          const { year, month } = getElSalvadorDateParts();
          const months = Array.from({ length: 4 }, (_, index) => {
            const date = new Date(Date.UTC(year, month - 1 - index, 1, 12));
            return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`;
          });
          requests = months.map((monthKey) => authenticatedApiFetch(
            `/api/cartera?action=estado-mensual&pais=${encodeURIComponent(currentCountry)}&mes=${encodeURIComponent(monthKey)}`,
            { cache: 'no-store' },
          ));
        }

        const responses = await Promise.all(requests);
        const rowGroups: Array<Record<string, any>[]> = [];
        for (const response of responses) {
          const payload = await response.json().catch(() => ({}));
          if (!response.ok || !payload.success) {
            throw new Error(payload.error || payload.message || `HTTP ${response.status}`);
          }
          if (isAdmin) {
            if (!Array.isArray(payload.records) || payload.truncated) {
              throw new Error('La bitácora administrativa está incompleta.');
            }
            rowGroups.push(payload.records);
          } else {
            const managementWarning = getManagementReadWarning(payload);
            if (managementWarning) throw new Error(managementWarning);
            rowGroups.push(payload.managed);
          }
        }

        if (!active) return;
        const mapped = rowGroups.flatMap((rows) => rows.flatMap((row) => {
          const agreement = String(row.agreement || '');
          if (agreement !== 'Promesa de Pago' && agreement !== 'Negociación de Cuotas') return [];
          if (row.aiVerdict === 'Inválida' || row.validacion_exitosa === false) return [];
          const values = row.dynamicValues && typeof row.dynamicValues === 'object'
            ? row.dynamicValues as Record<string, unknown>
            : {};
          const createdAt = String(row.timestamp || row.createdAt || '');
          const managementDate = getRecordDateKey({ timestamp: createdAt, date: String(row.date || '') })
            || String(row.scheduledForDate || '').slice(0, 10);
          const periodMonth = String(values.periodMonth || row.scheduledForDate?.slice(0, 7) || managementDate.slice(0, 7));
          const promiseDate = String(row.deadlineDate || values.deadlineDate || values.fecha_limite_pago || '');
          if (!promiseDate) return [];
          const amount = Number(row.committedAmount ?? values.committedAmount ?? values.monto_comprometido ?? 0);
        const promiseVerificationStatus = ['paid', 'unpaid', 'unknown'].includes(
          String(values.promiseVerificationStatus || ''),
        )
          ? String(values.promiseVerificationStatus) as PaymentAgreement['promiseVerificationStatus']
          : undefined;
          const clientCode = String(row.clientCode || '').trim();
          if (!clientCode) return [];
          const agentId = String(row.agentId || currentAgent?.id || '');
          return [{
            id: String(row.id),
            clientCode,
            clientName: String(row.clientName || clientCode),
            country: currentCountry,
            agreedAmount: Number.isFinite(amount) ? amount : 0,
            totalDebt: Number(row.totalDebt ?? values.totalDebt ?? 0) || 0,
            agreementDate: managementDate || createdAt.slice(0, 10),
            createdAt,
            periodMonth,
            promiseDate,
            promiseTime: String(row.promiseTime || values.promiseTime || '') || undefined,
            contactName: String(row.contactName || values.contactName || '') || undefined,
            contactEmail: String(row.contactEmail || values.contactEmail || '') || undefined,
            channel: String(row.channel || ''),
            managementDate: managementDate || undefined,
            managementTime: String(row.time || ''),
            scheduledForDate: String(row.scheduledForDate || values.scheduledForDate || '').slice(0, 10),
            status: getPromiseDisplayStatus(
              promiseVerificationStatus,
              promiseDate,
              todayKey,
              false,
            ),
            promiseVerificationStatus,
            installments: Number(values.installments || 1),
            agentId,
            agentName: agents.find((agent) => agent.id === agentId)?.name || String(row.agentName || currentAgent?.name || 'Agente de Cobro'),
            phone: String(row.contactPhone || values.contactPhone || '') || undefined,
            notes: String(row.observations || ''),
          }];
        }));
        const uniqueByDatabaseId = new Map(mapped.map((agreement) => [agreement.id, agreement]));
        setAgreements([...uniqueByDatabaseId.values()]);
      } catch (error) {
        if (active) {
          setAgreements([]);
          setAgreementReadError(`No se pudieron confirmar las promesas desde la bitácora: ${error instanceof Error ? error.message : 'error desconocido'}`);
        }
      } finally {
        requestInFlight = false;
        if (active) setIsLoadingAgreements(false);
      }
    };

    void loadPersistedAgreements();
    window.addEventListener('focus', loadPersistedAgreements);
    window.addEventListener('red-cobranza:audit-sync-complete', loadPersistedAgreements);
    return () => {
      active = false;
      window.removeEventListener('focus', loadPersistedAgreements);
      window.removeEventListener('red-cobranza:audit-sync-complete', loadPersistedAgreements);
    };
  }, [currentCountry, currentAgent, isAdmin, agents]);
  // The database row id is the only dedupe key; separate saved promises remain separate.
  const allRealAgreements = useMemo(() => {
    const map = new Map<string, PaymentAgreement>();
    agreements.forEach((a) => {
      if (a.country === currentCountry) {
        const periodMonth = a.periodMonth || a.agreementDate?.slice(0, 7);
        const normalized = {
          ...a,
          periodMonth,
          status: getPromiseDisplayStatus(
            a.promiseVerificationStatus,
            a.promiseDate,
            todayKey,
            isResolvedInOrAfterPromiseMonth(
              monthlyResolvedKeys,
              a.country,
              a.clientCode,
              periodMonth,
            ),
          ),
        };
        map.set(a.id, normalized);
      }
    });
    return latestPromisePerClient(Array.from(map.values()));
  }, [agreements, currentCountry, monthlyResolvedKeys]);

  const verifiedRealAgreements = useMemo(() => {
    const eligibleCodes = agendaEligibilityLoading || agendaEligibilityError
      ? null
      : agendaEligibleCodes;
    return filterAgreementsByVerifiedEligibility(allRealAgreements, eligibleCodes);
  }, [allRealAgreements, agendaEligibleCodes, agendaEligibilityLoading, agendaEligibilityError]);

  // Temporary UI updates are reloaded from persisted bitácora / monthly state.
  const saveAgreements = (updated: PaymentAgreement[]) => {
    const countryAgreements = updated.filter((agreement) => agreement.country === currentCountry);
    setAgreements(countryAgreements);
  };

  const agreementsForSelectedDate = verifiedRealAgreements
    .filter((agreement) => agreement.promiseDate === selectedPromiseDate && agreement.status === 'Pendiente')
    .sort((a, b) => `${a.promiseTime || ''}${a.clientName}`.localeCompare(`${b.promiseTime || ''}${b.clientName}`));

  const handleValidatePromisesForDate = async () => {
    setIsValidatingPromises(true);
    setPromiseValidationResult('');
    if (agreementsForSelectedDate.length === 0) {
      setPromiseValidationResult('No hay promesas pendientes para esta fecha.');
      setIsValidatingPromises(false);
      return;
    }

    type ClientPromiseCheck = {
      outcome: 'paid' | 'unpaid' | 'unknown' | 'not_due';
      month?: string;
      availableOn?: string;
    };
    const clientKey = (agreement: PaymentAgreement) =>
      `${agreement.country}:${agreement.clientCode.trim().toLocaleUpperCase()}`;
    const uniqueClients = Array.from(
      new Map(agreementsForSelectedDate.map((agreement) => [clientKey(agreement), agreement])).values()
    );
    const checksByClient = new Map<string, ClientPromiseCheck>();

    const checkClient = async (agreement: PaymentAgreement): Promise<ClientPromiseCheck> => {
      try {
        const response = await authenticatedApiFetch('/api/cartera?action=corroborar-promesa', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            pais: agreement.country,
            codigo_cliente: agreement.clientCode,
          }),
        });
        const payload = await response.json().catch(() => ({}));
        if (payload.error === 'PROMISE_NOT_DUE') {
          return { outcome: 'not_due', availableOn: String(payload.availableOn || '') };
        }
        if (!response.ok || !payload.success) return { outcome: 'unknown' };
        return {
          outcome: payload.status === 'Cumplido' ? 'paid' : 'unpaid',
          month: String(payload.mes || ''),
        };
      } catch {
        return { outcome: 'unknown' };
      }
    };

    for (let index = 0; index < uniqueClients.length; index += 4) {
      const batch = uniqueClients.slice(index, index + 4);
      await Promise.all(batch.map(async (agreement) => {
        checksByClient.set(clientKey(agreement), await checkClient(agreement));
      }));
    }
    const checks = agreementsForSelectedDate.map((agreement) => ({
      agreement,
      ...(checksByClient.get(clientKey(agreement)) || { outcome: 'unknown' as const }),
    }));

    const paid = checks.filter((check) => check.outcome === 'paid').map((check) => check.agreement);
    const unpaid = checks.filter((check) => check.outcome === 'unpaid');
    const notDue = checks.filter((check) => check.outcome === 'not_due');
    const unknown = checks.filter((check) => check.outcome === 'unknown');
    setUnpaidPromises(Object.fromEntries(unpaid.map((check) => [
      check.agreement.id,
      ['Saldo pendiente según SAN'],
    ])));

    const paidClientMonths = new Map<string, { country: Country; clientCode: string; month: string }>();
    checks.filter((check) => check.outcome === 'paid').forEach((check) => {
      const { agreement } = check;
      const month = check.month || agreement.periodMonth || agreement.agreementDate?.slice(0, 7) || '';
      if (!month) return;
      const key = `${agreement.country}:${agreement.clientCode}:${month}`;
      paidClientMonths.set(key, { country: agreement.country, clientCode: agreement.clientCode, month });
    });
    const persistedClientMonths = new Set(paidClientMonths.keys());
    const persistedPaid = paid;

    if (persistedPaid.length > 0) {
      const persistedKeys = Array.from(persistedClientMonths);
      setMonthlyResolvedKeys((current) => Array.from(new Set([...current, ...persistedKeys])));
    }
    window.dispatchEvent(new Event('red-cobranza:audit-sync-complete'));

    const parts = [
      persistedPaid.length ? `${persistedPaid.length} promesa(s) cumplida(s); cartera mensual resuelta.` : '',
      unpaid.length ? `${unpaid.length} cliente(s) aún tienen facturas pendientes.` : '',
      notDue.length ? `${notDue.length} promesa(s) se revisarán cuando venza la factura que se está cobrando.` : '',
      unknown.length ? `${unknown.length} cliente(s) sin datos verificables; no se cambió su estado.` : '',
    ].filter(Boolean);
    setPromiseValidationResult(parts.join(' '));
    setIsValidatingPromises(false);
  };

  const filteredAgreements = useMemo(() => {
    return verifiedRealAgreements.filter((a) => {
      if (statusFilter !== 'TODOS' && a.status !== statusFilter) return false;
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchCode = (a.clientCode || '').toLowerCase().includes(q);
        const matchName = (a.clientName || '').toLowerCase().includes(q);
        const matchAgent = (a.agentName || '').toLowerCase().includes(q);
        if (!matchCode && !matchName && !matchAgent) return false;
      }
      return true;
    });
  }, [verifiedRealAgreements, statusFilter, searchTerm]);

  // Financial KPIs from REAL agreements
  const totalAgreed = verifiedRealAgreements.reduce((sum, a) => sum + (Number(a.agreedAmount) || 0), 0);
  const fulfilledAgreements = verifiedRealAgreements.filter((a) => a.status === 'Cumplido');
  const fulfilledAmount = fulfilledAgreements.reduce((sum, a) => sum + (Number(a.agreedAmount) || 0), 0);
  const pendingAgreements = verifiedRealAgreements.filter((a) => a.status === 'Pendiente');
  const pendingAmount = pendingAgreements.reduce((sum, a) => sum + (Number(a.agreedAmount) || 0), 0);
  const expiredAgreements = verifiedRealAgreements.filter((a) => a.status === 'Vencido');
  const fulfillmentRate = totalAgreed > 0 ? ((fulfilledAmount / totalAgreed) * 100).toFixed(1) : '0.0';

  const handleMarkAsFulfilled = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAgreementForFulfill) return;

    const updated = verifiedRealAgreements.map((a) => {
      if (a.id === selectedAgreementForFulfill.id) {
        return {
          ...a,
          status: 'Cumplido' as const,
          receiptNumber: receiptNumber.trim() || `REC-${Date.now().toString().slice(-6)}`,
          fulfilledDate: todayKey,
          notes: fulfillNotes.trim() ? `${a.notes ? a.notes + ' | ' : ''}${fulfillNotes.trim()}` : a.notes,
        };
      }
      return a;
    });

    saveAgreements(updated);
    setIsFulfillModalOpen(false);
    setSelectedAgreementForFulfill(null);
    setReceiptNumber('');
    setFulfillNotes('');
  };

  const handleOpenClientGestion = (clientCode: string) => {
    const client = clients.find((c) => c.code === clientCode);
    if (client && onOpenGestionModal) {
      const currentPromise = verifiedRealAgreements.find((agreement) =>
        agreement.clientCode.trim().toUpperCase() === clientCode.trim().toUpperCase()
      );
      onOpenGestionModal({
        ...client,
        paymentPromiseForVerification: currentPromise
          ? {
              promiseDate: currentPromise.promiseDate,
              status: currentPromise.promiseVerificationStatus,
            }
          : undefined,
      });
    }
  };

  const handleExportExcel = () => {
    if (verifiedRealAgreements.length === 0) {
      alert('No hay acuerdos reales registrados para exportar.');
      return;
    }

    const headers = [
      'ID Acuerdo',
      'Código Cliente',
      'Nombre Cliente',
      'País',
      'Monto Acordado',
      'Deuda Total',
      'Fecha Acuerdo',
      'Fecha Prometida',
      'Estado',
      'Cuotas',
      'Gestor Responsable',
      'Canal de gestión',
      'Contacto',
      'Correo de contacto',
      'Teléfono',
      'Fecha de gestión',
      'Hora de gestión',
      'Día de agenda',
      'No. Comprobante',
      'Fecha Cumplimiento',
      'Observaciones',
    ];

    const rows = filteredAgreements.map((a) => [
      a.id,
      a.clientCode,
      a.clientName,
      a.country === 'SV' ? 'El Salvador' : 'Guatemala',
      a.agreedAmount,
      a.totalDebt,
      a.agreementDate,
      a.promiseDate,
      a.status,
      a.installments || 1,
      a.agentName,
      a.channel || '',
      a.contactName || '',
      a.contactEmail || '',
      a.phone || '',
      a.managementDate || '',
      a.managementTime || '',
      a.scheduledForDate || '',
      a.receiptNumber || '',
      a.fulfilledDate || '',
      a.notes || '',
    ]);

    const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    ws['!cols'] = [
      { wch: 15 },
      { wch: 14 },
      { wch: 35 },
      { wch: 14 },
      { wch: 16 },
      { wch: 16 },
      { wch: 14 },
      { wch: 16 },
      { wch: 12 },
      { wch: 8 },
      { wch: 22 },
      { wch: 18 },
      { wch: 28 },
      { wch: 32 },
      { wch: 16 },
      { wch: 18 },
      { wch: 16 },
      { wch: 16 },
      { wch: 16 },
      { wch: 18 },
      { wch: 40 },
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Acuerdos Reales');
    XLSX.writeFile(wb, `Acuerdos_Reales_${currentCountry}_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="glass-panel rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-widest mb-1.5">
            <CircleDollarSign className="w-4 h-4 text-emerald-400" />
            <span>Módulo de Compromisos y Cierre Financiero · {currentCountry === 'SV' ? '🇸🇻 El Salvador' : '🇬🇹 Guatemala'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Gestión y Control de Acuerdos de Pago
          </h2>
          <p className="text-sm text-slate-300 mt-1 max-w-2xl">
            Supervisa las promesas de pago reales pactadas durante las gestiones de cobro. Registra pagos verificados con número de recibo bancario y controla plazos de vencimiento.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {verifiedRealAgreements.length > 0 && (
            <button
              onClick={handleExportExcel}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>Exportar Excel</span>
            </button>
          )}

          <DateInput
            value={selectedPromiseDate}
            onChange={(value) => {
              setSelectedPromiseDate(value);
              setPromiseValidationResult('');
              setUnpaidPromises({});
            }}
            ariaLabel="Fecha de promesas para sincronizar con SAN"
            className="min-w-0 flex-1 rounded-xl glass-input px-3 py-2.5 text-xs font-mono"
          />
          <button
            type="button"
            onClick={handleValidatePromisesForDate}
            disabled={isValidatingPromises || agreementsForSelectedDate.length === 0}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:from-slate-800 disabled:to-slate-800 text-white disabled:text-slate-500 text-xs font-bold shadow-lg shadow-emerald-600/30 disabled:shadow-none transition-all cursor-pointer disabled:cursor-not-allowed"
          >
            <RefreshCw className={`w-4 h-4 ${isValidatingPromises ? 'animate-spin' : ''}`} />
            <span>{isValidatingPromises ? 'Consultando SAN…' : 'Sincronizar con API de SAN'}</span>
          </button>
        </div>
      </div>

      {agreementReadError && (
        <div className="rounded-xl border border-amber-700/50 bg-amber-950/30 px-4 py-3 text-sm text-amber-200" role="alert">
          {agreementReadError} No se mostrarán datos locales como si fueran promesas guardadas.
        </div>
      )}
      {agendaEligibilityError && (
        <div className="rounded-xl border border-amber-700/50 bg-amber-950/30 px-4 py-3 text-sm text-amber-200" role="alert">
          {agendaEligibilityError}
        </div>
      )}

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Pactado en Acuerdos</span>
            <CircleDollarSign className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-black font-mono text-white mt-2 tabular-nums">
            {currentCountry === 'SV' ? '$' : 'Q'}{totalAgreed.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            {verifiedRealAgreements.length} compromisos registrados
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Recuperado (Cumplidos)</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black font-mono text-emerald-400 mt-2 tabular-nums">
            {currentCountry === 'SV' ? '$' : 'Q'}{fulfilledAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-emerald-400/90 mt-1 font-mono font-semibold">
            {fulfilledAgreements.length} acuerdos pagados ({fulfillmentRate}% efectividad)
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Promesas Pendientes</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black font-mono text-amber-300 mt-2 tabular-nums">
            {currentCountry === 'SV' ? '$' : 'Q'}{pendingAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-amber-400/90 mt-1 font-mono">
            {pendingAgreements.length} en espera de fecha prometida
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Acuerdos Vencidos / Rotos</span>
            <AlertTriangle className="w-4 h-4 text-red-400" />
          </div>
          <div className="text-2xl font-black font-mono text-red-400 mt-2 tabular-nums">
            {expiredAgreements.length}
          </div>
          <div className="text-[11px] text-red-400/90 mt-1 font-mono">
            Requieren llamada de renegociación
          </div>
        </div>
      </div>

      {/* One agreements table with date validation controls */}
      <div className="glass-panel rounded-2xl p-4 space-y-3">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-3">
          <div className="relative w-full xl:max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar por cliente, código o gestor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-xs rounded-xl glass-input text-white placeholder:text-slate-500"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto w-full xl:w-auto">
            {(['TODOS', 'Pendiente', 'Cumplido', 'Vencido'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  statusFilter === st
                    ? st === 'Cumplido'
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                      : st === 'Vencido'
                      ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                      : 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'bg-slate-900/80 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
                }`}
              >
                {st === 'TODOS' ? 'Todos los Estados' : st}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-slate-800 pt-3">
          <p className="text-[11px] text-slate-400">
            Consulta SAN en vivo para las promesas pendientes de la fecha elegida.
            <span className="ml-1 text-slate-300">{agreementsForSelectedDate.length} pendientes</span>
          </p>
          <span className="text-[11px] text-slate-400">
            Fecha consultada: <span className="font-mono text-slate-200">{selectedPromiseDate}</span>
          </span>
        </div>

        {promiseValidationResult && (
          <div className="rounded-xl border border-blue-700/40 bg-blue-950/30 px-3 py-2 text-xs text-blue-200" role="status">
            {promiseValidationResult}
          </div>
        )}
      </div>

      {/* Table of Agreements */}
      <div className="glass-panel rounded-2xl overflow-hidden border border-slate-800">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/90 text-slate-400 uppercase font-semibold text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4 font-mono">Cód. Cliente</th>
                <th className="py-3 px-4">Cliente Real</th>
                <th className="py-3 px-4 text-right">Monto Pactado</th>
                <th className="py-3 px-4 text-center">Fecha Prometida</th>
                <th className="py-3 px-4 text-center">Estado</th>
                <th className="py-3 px-4">Gestor</th>
                <th className="py-3 px-4">Observaciones / Comprobante</th>
                <th className="py-3 px-4 text-center">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {filteredAgreements.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-16 text-center text-slate-400">
                    <div className="max-w-md mx-auto space-y-3">
                      <div className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 text-slate-500 flex items-center justify-center mx-auto">
                        <CircleDollarSign className="w-6 h-6" />
                      </div>
                      <div className="text-sm font-bold text-slate-300">
                        {isLoadingAgreements
                          ? 'Consultando promesas guardadas en la bitácora…'
                          : agendaEligibilityLoading
                            ? 'Verificando facturas vencidas en SAN…'
                            : agendaEligibilityError
                              ? 'No se pudo verificar la mora en SAN'
                              : agreementReadError
                            ? 'No se pudo verificar la bitácora'
                            : 'No hay acuerdos ni promesas de pago registrados'}
                      </div>
                      <p className="text-xs text-slate-500 leading-relaxed">
                        {isLoadingAgreements
                          ? 'Esta vista espera la respuesta confirmada del servidor.'
                          : agendaEligibilityLoading
                            ? 'Las promesas abiertas se mostrarán cuando termine la verificación de la cartera.'
                            : agendaEligibilityError
                              ? 'No se mostrarán promesas pendientes o vencidas hasta confirmar que el cliente aún tiene facturas vencidas.'
                              : agreementReadError
                            ? 'Corrige la conexión y vuelve a cargar para consultar los datos persistidos.'
                            : 'Los acuerdos aparecerán aquí cuando un agente registre una promesa de pago válida durante una gestión.'}
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredAgreements.map((agr) => {
                  return (
                    <tr key={agr.id} className="hover:bg-slate-900/40 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-blue-400">
                        {agr.clientCode}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white truncate max-w-xs">{agr.clientName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          Deuda total: ${Number(agr.totalDebt || 0).toLocaleString()}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-black text-emerald-300 tabular-nums">
                        {currentCountry === 'SV' ? '$' : 'Q'}{Number(agr.agreedAmount || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        {agr.installments && agr.installments > 1 && (
                          <div className="text-[10px] text-slate-400 font-normal">en {agr.installments} cuotas</div>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center font-mono">
                        <div className="text-slate-200">{agr.promiseDate}</div>
                        <div className="text-[10px] text-slate-500">Pactado el {agr.agreementDate}</div>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                            agr.status === 'Cumplido'
                              ? 'bg-emerald-950/80 text-emerald-300 border-emerald-600/50'
                              : agr.status === 'Vencido'
                              ? 'bg-red-950/80 text-red-300 border-red-600/50'
                              : 'bg-amber-950/80 text-amber-300 border-amber-600/50'
                          }`}
                        >
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              agr.status === 'Cumplido'
                                ? 'bg-emerald-400'
                                : agr.status === 'Vencido'
                                ? 'bg-red-400'
                                : 'bg-amber-400'
                            }`}
                          />
                          {agr.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-300 font-medium">
                        {agr.agentName}
                      </td>
                      <td className="py-3 px-4 max-w-xs">
                        {agr.receiptNumber && (
                          <div className="text-emerald-400 font-mono text-[11px] font-bold mb-0.5">
                            Comprobante: {agr.receiptNumber}
                          </div>
                        )}
                        <div className="text-slate-400 truncate text-[11px]" title={agr.notes}>
                          {agr.notes || 'Sin observaciones'}
                        </div>
                        {unpaidPromises[agr.id] && (
                          <div className="mt-2 space-y-2 rounded-lg border border-amber-500/30 bg-amber-500/5 p-2">
                            <p className="text-[11px] text-amber-200">
                              Facturas pendientes: {unpaidPromises[agr.id].join(', ')}. Programa seguimiento.
                            </p>
                            <div className="flex flex-wrap gap-2">
                              <DateInput
                                value={followUpDates[agr.id] || ''}
                                min={todayKey}
                                max={endOfCurrentMonth}
                                onChange={(value) => setFollowUpDates((previous) => ({
                                  ...previous,
                                  [agr.id]: value,
                                }))}
                                ariaLabel={`Fecha de seguimiento para ${agr.clientCode}`}
                                className="min-w-0 flex-1 rounded-lg glass-input px-2 py-1.5 text-[11px] font-mono"
                              />
                              <button
                                type="button"
                                disabled={!followUpDates[agr.id]}
                                onClick={() => {
                                  const date = followUpDates[agr.id];
                                  if (!date || !onScheduleFollowUp) return;
                                  onScheduleFollowUp(agr.clientCode, date, 'Segunda llamada de seguimiento');
                                  setPromiseValidationResult(`Segunda llamada programada para ${agr.clientCode} el ${date}.`);
                                }}
                                className="rounded-lg border border-amber-500/40 bg-amber-600/20 px-2 py-1.5 text-[11px] font-bold text-amber-200 hover:bg-amber-600/30 disabled:opacity-40"
                              >
                                Programar seguimiento
                              </button>
                            </div>
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          {false && agr.status !== 'Cumplido' && (
                            <button
                              onClick={() => {
                                setSelectedAgreementForFulfill(agr);
                                setIsFulfillModalOpen(true);
                              }}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold transition-all cursor-pointer"
                              title="Marcar como cumplido / registrar pago"
                            >
                              Registrar Pago
                            </button>
                          )}

                          <button
                            onClick={() => setInspectedAgreement(agr)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer"
                            title="Ver detalle del acuerdo"
                          >
                            <Info className="w-3.5 h-3.5 text-blue-400" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenClientGestion(agr.clientCode)}
                            className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-600/20 px-2.5 py-1.5 text-[11px] font-bold text-emerald-200 transition-colors hover:bg-emerald-600/35"
                            title={`Registrar una nueva gestión para ${agr.clientCode}`}
                          >
                            <ExternalLink className="h-3.5 w-3.5" />
                            Gestionar
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Detalle de Acuerdo Inspected */}
      {inspectedAgreement && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl glass-panel border border-slate-700 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Info className="w-5 h-5 text-blue-400" />
                Detalle del Compromiso de Pago
              </h3>
              <button
                onClick={() => setInspectedAgreement(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <div className="text-[10px] uppercase tracking-wider text-slate-400">Cliente</div>
                <div className="text-sm font-bold text-white">{inspectedAgreement.clientName}</div>
                <div className="text-[11px] text-blue-400 font-mono">Código: {inspectedAgreement.clientCode}</div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="text-[10px] text-slate-400">Monto Pactado</div>
                  <div className="text-base font-black font-mono text-emerald-400 mt-0.5">
                    {currentCountry === 'SV' ? '$' : 'Q'}{Number(inspectedAgreement.agreedAmount || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="text-[10px] text-slate-400">Fecha Prometida</div>
                  <div className="text-sm font-mono font-bold text-white mt-1">
                    {inspectedAgreement.promiseDate}
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-400">Estado</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      inspectedAgreement.status === 'Cumplido'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : inspectedAgreement.status === 'Vencido'
                        ? 'bg-red-950 text-red-300 border border-red-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}
                  >
                    {inspectedAgreement.status}
                  </span>
                </div>
                <div className="text-[11px] text-slate-300 pt-1">
                  Gestor responsable: <strong>{inspectedAgreement.agentName}</strong>
                </div>
                {inspectedAgreement.channel && (
                  <div className="text-[11px] text-slate-300">
                    Canal de gestión: <strong>{inspectedAgreement.channel}</strong>
                  </div>
                )}
                {inspectedAgreement.contactName && (
                  <div className="text-[11px] text-slate-300">
                    Contacto: <strong>{inspectedAgreement.contactName}</strong>
                  </div>
                )}
                {inspectedAgreement.contactEmail && (
                  <div className="text-[11px] text-slate-300 break-all">
                    Correo de contacto: <strong>{inspectedAgreement.contactEmail}</strong>
                  </div>
                )}
                {inspectedAgreement.phone && (
                  <div className="text-[11px] text-slate-300">
                    Teléfono de contacto: <strong>{inspectedAgreement.phone}</strong>
                  </div>
                )}
                {(inspectedAgreement.managementDate || inspectedAgreement.managementTime) && (
                  <div className="text-[11px] text-slate-300">
                    Gestión registrada: <strong>{[inspectedAgreement.managementDate, inspectedAgreement.managementTime].filter(Boolean).join(' · ')}</strong>
                  </div>
                )}
                {inspectedAgreement.scheduledForDate && (
                  <div className="text-[11px] text-slate-300">
                    Día de agenda contabilizado: <strong>{inspectedAgreement.scheduledForDate}</strong>
                  </div>
                )}
                {inspectedAgreement.receiptNumber && (
                  <div className="text-[11px] text-emerald-400 font-mono font-semibold">
                    Comprobante: {inspectedAgreement.receiptNumber} (Pagado el {inspectedAgreement.fulfilledDate})
                  </div>
                )}
                {inspectedAgreement.notes && (
                  <div className="text-[11px] text-slate-400 pt-1 border-t border-slate-800 mt-2">
                    Notas: {inspectedAgreement.notes}
                  </div>
                )}
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  const code = inspectedAgreement.clientCode;
                  setInspectedAgreement(null);
                  handleOpenClientGestion(code);
                }}
                className="flex-1 py-2 px-3 rounded-xl text-xs font-semibold text-blue-300 bg-blue-950/60 hover:bg-blue-900/80 border border-blue-800/80 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Abrir Bitácora Completa</span>
              </button>

              <button
                type="button"
                onClick={() => setInspectedAgreement(null)}
                className="py-2 px-4 rounded-xl text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Marcar Acuerdo Cumplido */}
      {isFulfillModalOpen && selectedAgreementForFulfill && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl glass-panel border border-slate-700 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                Registrar Pago de Promesa
              </h3>
              <button
                onClick={() => setIsFulfillModalOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
              <div className="text-xs font-bold text-white">{selectedAgreementForFulfill.clientName}</div>
              <div className="text-[11px] text-slate-400 font-mono">
                Cód: <span className="text-blue-400">{selectedAgreementForFulfill.clientCode}</span> · Monto: <span className="text-emerald-400 font-bold">${Number(selectedAgreementForFulfill.agreedAmount || 0).toLocaleString()}</span>
              </div>
            </div>

            <form onSubmit={handleMarkAsFulfilled} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Número de Comprobante / Recibo de Pago *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej: REC-992384 o Ref. Transferencia"
                  value={receiptNumber}
                  onChange={(e) => setReceiptNumber(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl glass-input font-mono text-white placeholder:text-slate-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Notas de Confirmación
                </label>
                <textarea
                  rows={2}
                  placeholder="Ej: Transferencia acreditada en cuenta del BAC..."
                  value={fulfillNotes}
                  onChange={(e) => setFulfillNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl glass-input text-white placeholder:text-slate-500"
                />
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsFulfillModalOpen(false)}
                  className="flex-1 py-2 px-3 rounded-xl text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 px-3 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/30 cursor-pointer"
                >
                  Confirmar Pago Recibido
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
