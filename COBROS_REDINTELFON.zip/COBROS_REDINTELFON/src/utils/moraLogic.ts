import { Agent, Client, MoraRange } from '../types';

export interface MoraPhaseInfo {
  range: MoraRange;
  label: string;
  sublabel: string;
  badgeClass: string;
  bgGradient: string;
  textColor: string;
  borderColor: string;
  iconName: string;
}

export const MORA_PHASES: Record<MoraRange, MoraPhaseInfo> = {
  '0-30': {
    range: '0-30',
    label: '0-30 días',
    sublabel: 'No moroso (Factura dentro del período normal)',
    badgeClass: 'bg-blue-950/80 text-blue-300 border-blue-800/60',
    bgGradient: 'from-blue-600/20 to-blue-900/30',
    textColor: 'text-blue-400',
    borderColor: 'border-blue-500/40',
    iconName: 'ShieldCheck',
  },
  '31-60': {
    range: '31-60',
    label: '31-60 días',
    sublabel: 'Primer contacto (Gestión preventiva)',
    badgeClass: 'bg-orange-950/80 text-orange-300 border-orange-800/60',
    bgGradient: 'from-orange-500/20 to-amber-900/30',
    textColor: 'text-orange-400',
    borderColor: 'border-orange-500/40',
    iconName: 'PhoneCall',
  },
  '61-90': {
    range: '61-90',
    label: '61-90 días',
    sublabel: 'Segundo contacto (Seguimiento moderado)',
    badgeClass: 'bg-amber-950/80 text-amber-300 border-amber-800/60',
    bgGradient: 'from-amber-500/20 to-yellow-900/30',
    textColor: 'text-amber-400',
    borderColor: 'border-amber-500/40',
    iconName: 'Clock',
  },
  '91-120': {
    range: '91-120',
    label: '91-120 días',
    sublabel: 'Tercer contacto (Urgencia)',
    badgeClass: 'bg-orange-950/90 text-orange-200 border-orange-700/70',
    bgGradient: 'from-orange-600/25 to-red-950/40',
    textColor: 'text-orange-300',
    borderColor: 'border-orange-600/50',
    iconName: 'AlertTriangle',
  },
  '120+': {
    range: '120+',
    label: '120+ días',
    sublabel: 'Crítico (Requiere escalación inmediata)',
    badgeClass: 'bg-red-950/90 text-red-200 border-red-700/80',
    bgGradient: 'from-red-600/30 to-red-950/50',
    textColor: 'text-red-400',
    borderColor: 'border-red-600/60',
    iconName: 'AlertOctagon',
  },
};

export function calculateMoraRange(daysArrears: number): MoraRange {
  if (daysArrears <= 30) return '0-30';
  if (daysArrears <= 60) return '31-60';
  if (daysArrears <= 90) return '61-90';
  if (daysArrears <= 120) return '91-120';
  return '120+';
}

/**
 * Generates schedule business days (Monday to Friday) for the month
 */
export function getBusinessDaysInMonth(year: number, monthZeroIndexed: number): string[] {
  const days: string[] = [];
  const date = new Date(year, monthZeroIndexed, 1);
  while (date.getMonth() === monthZeroIndexed) {
    const dayOfWeek = date.getDay(); // 0 is Sunday, 6 is Saturday
    if (dayOfWeek !== 0 && dayOfWeek !== 6) {
      days.push(date.toISOString().split('T')[0]);
    }
    date.setDate(date.getDate() + 1);
  }
  return days;
}

/**
 * Standard business calling time slots between 8:00 AM and 6:00 PM
 */
export const BUSINESS_HOURS_SLOTS = [
  '08:00 AM',
  '08:45 AM',
  '09:30 AM',
  '10:15 AM',
  '11:00 AM',
  '11:45 AM',
  '01:15 PM',
  '02:00 PM',
  '02:45 PM',
  '03:30 PM',
  '04:15 PM',
  '05:00 PM',
];

/**
 * Distribute clients equally among agents of the same country,
 * then partition each agent's portfolio across business days (Mon-Fri 8am-6pm).
 */
export function distributeClientsEqually(
  clients: Client[],
  agents: Agent[],
  year = 2026,
  monthZeroIndexed = 9 // October (0-indexed 9)
): Client[] {
  const businessDays = getBusinessDaysInMonth(year, monthZeroIndexed);
  
  // Filter only active clients in the portfolio as strictly required
  const isClientActive = (c: Client): boolean => {
    const s = String(c.estatus || c.status || '').toUpperCase();
    if (s.includes('INACT') || s.includes('BAJA') || s.includes('CANCEL') || s.includes('SUSPEND') || s === 'NO ACTIVO') {
      return false;
    }
    return true;
  };

  const updatedClients: Client[] = clients.filter(isClientActive).map((c) => ({ ...c }));

  // Group agents by country (only users with role 'agente', not admins)
  const agentsSV = agents.filter((a) => a.country === 'SV' && a.status === 'activo' && a.role === 'agente');
  const agentsGT = agents.filter((a) => a.country === 'GT' && a.status === 'activo' && a.role === 'agente');

  const distributeForCountry = (countryAgents: Agent[], country: 'SV' | 'GT') => {
    if (countryAgents.length === 0) return;

    // Separate clients that already have a manual assignment from unassigned ones
    const countryClientIndices = updatedClients
      .map((c, idx) => ({ client: c, idx }))
      .filter((item) => item.client.country === country);

    // Keep manual assignments intact, distribute the rest
    const unassignedIndices = countryClientIndices.filter((item) => !item.client.isManualAssignment);

    unassignedIndices.forEach(({ idx }, i) => {
      const assignedAgent = countryAgents[i % countryAgents.length];
      const agentClientIndex = Math.floor(i / countryAgents.length);
      const dayAssigned = businessDays[agentClientIndex % businessDays.length];
      const slotIndex = Math.floor(agentClientIndex / businessDays.length) % BUSINESS_HOURS_SLOTS.length;
      const scheduledTime = BUSINESS_HOURS_SLOTS[slotIndex];

      updatedClients[idx] = {
        ...updatedClients[idx],
        assignedAgentId: assignedAgent.id,
        assignedAgentName: assignedAgent.name,
        scheduledTime,
      };
    });

    // For manually assigned clients, ensure they also have scheduling slots
    const manualIndices = countryClientIndices.filter((item) => item.client.isManualAssignment);
    manualIndices.forEach(({ idx }, i) => {
      const slotIndex = i % BUSINESS_HOURS_SLOTS.length;
      updatedClients[idx] = {
        ...updatedClients[idx],
        scheduledTime: updatedClients[idx].scheduledTime || BUSINESS_HOURS_SLOTS[slotIndex],
      };
    });
  };

  distributeForCountry(agentsSV, 'SV');
  distributeForCountry(agentsGT, 'GT');

  return updatedClients;
}

/**
 * METHODOLOGY: DISTRIBUTION OF CLIENTS FROM DAY 1 TO 21 (DEFAULT: 40 PER DAY)
 * --------------------------------------------------------------------------
 * 1. Operational Window: Weekdays from day 1 through day 21 of the month.
 * 2. Daily Goal: Configurable `clientsPerDay` (default 40 calls/day).
 * 3. From day 22 through month-end, follow up unresolved clients without an
 *    active promise on the next business day, plus verified overdue promises.
 * 4. Priority Multi-Call Strategy:
 *    - To fulfill the daily call volume, clients can and should be contacted multiple times:
 *      * Critical Clients (120+ days & 91-120 days): 3 rounds of calls.
 *        - Round 1 (Days 1-7): Immediate intervention & notice of service cut.
 *        - Round 2 (Days 8-15): Follow-up & negotiation of emergency payment agreement.
 *        - Round 3 (Days 16-21): Final closing before judicial escalation.
 *      * Moderate Mora Clients (31-60 & 61-90 days): 2 rounds of calls.
 *        - Round 1 (Days 1-11): Verification of invoice reception and payment scheduling.
 *        - Round 2 (Days 12-21): Confirmation of transfer and reconciliation.
 *      * Regular Clients (0-30 days / month billing): 1 to 2 rounds.
 *        - Round 1: Preventive reminder before invoice cutoff date.
 * 5. In the daily agenda, each call clearly displays the call round:
 *    e.g. "1ª Llamada (Corte/Preventivo)", "2ª Llamada (Seguimiento)", "3ª Llamada (Intensiva)".
 * 6. Dynamic Rebalancing:
 *    - When rescheduling to day D, if day D exceeds the quota, the lowest urgency call
 *      moves to the next available business day (never beyond day 21).
 */
export const OPERATIONAL_DAYS_MAX = 21;
export const PROMISE_FOLLOWUP_START_DAY = 22;

export function getOperationalBusinessDayNumbers(
  year: number,
  monthZeroIndexed: number,
): number[] {
  const lastDay = Math.min(
    OPERATIONAL_DAYS_MAX,
    new Date(Date.UTC(year, monthZeroIndexed + 1, 0)).getUTCDate(),
  );
  return Array.from({ length: lastDay }, (_, index) => index + 1)
    .filter((day) => {
      const weekday = new Date(Date.UTC(year, monthZeroIndexed, day, 12)).getUTCDay();
      return weekday !== 0 && weekday !== 6;
    });
}

export function isBusinessDayOfMonth(
  year: number,
  monthZeroIndexed: number,
  day: number,
): boolean {
  const weekday = new Date(Date.UTC(year, monthZeroIndexed, day, 12)).getUTCDay();
  return weekday !== 0 && weekday !== 6;
}

export function normalizeToBusinessDay(
  year: number,
  monthZeroIndexed: number,
  day: number,
  maxDay = OPERATIONAL_DAYS_MAX,
): number {
  const lastDay = Math.min(
    maxDay,
    new Date(Date.UTC(year, monthZeroIndexed + 1, 0)).getUTCDate(),
  );
  const requestedDay = Math.min(Math.max(1, Math.trunc(day)), lastDay);

  for (let candidate = requestedDay; candidate <= lastDay; candidate++) {
    if (isBusinessDayOfMonth(year, monthZeroIndexed, candidate)) return candidate;
  }
  for (let candidate = requestedDay - 1; candidate >= 1; candidate--) {
    if (isBusinessDayOfMonth(year, monthZeroIndexed, candidate)) return candidate;
  }
  return requestedDay;
}

export interface ScheduledCallSlot {
  client: Client;
  scheduledDay: number;
  callRound: number;
  callRoundLabel: string;
  turnNumber: number;
  timeSlot: string;
}

export function buildWorkloadSchedule1To21(
  clients: Client[],
  year: number,
  monthZeroIndexed: number,
  clientsPerDay: number = 40
): Record<number, ScheduledCallSlot[]> {
  const schedule: Record<number, ScheduledCallSlot[]> = {};
  for (let d = 1; d <= OPERATIONAL_DAYS_MAX; d++) {
    schedule[d] = [];
  }

  if (!clients || clients.length === 0) return schedule;
  const businessDays = getOperationalBusinessDayNumbers(year, monthZeroIndexed);
  if (businessDays.length === 0) return schedule;
  const firstRoundEnd = Math.ceil(businessDays.length / 3);
  const secondRoundEnd = Math.ceil((businessDays.length * 2) / 3);
  const moderateRoundEnd = Math.ceil(businessDays.length / 2);

  // 1. Separate clients by urgency tier
  const criticalTier = clients.filter((c) => c.moraRange === '120+' || c.moraRange === '91-120');
  const moderateTier = clients.filter((c) => c.moraRange === '61-90' || c.moraRange === '31-60');
  const normalTier = clients.filter((c) => c.moraRange === '0-30');

  // Sort each tier by highest debt first
  const sortByDebt = (a: Client, b: Client) =>
    (b.totalDebt || 0) - (a.totalDebt || 0)
    || a.code.trim().toUpperCase().localeCompare(b.code.trim().toUpperCase());
  criticalTier.sort(sortByDebt);
  moderateTier.sort(sortByDebt);
  normalTier.sort(sortByDebt);

  // Helper to add a call slot to a day
  const addSlot = (day: number, client: Client, round: number, roundLabel: string) => {
    const validDay = Math.min(Math.max(1, day), OPERATIONAL_DAYS_MAX);
    const daySlots = schedule[validDay];
    const turnNumber = daySlots.length + 1;
    const timeSlot = BUSINESS_HOURS_SLOTS[(turnNumber - 1) % BUSINESS_HOURS_SLOTS.length];

    daySlots.push({
      client: {
        ...client,
        scheduledDay: validDay,
        callRound: round,
        callRoundLabel: roundLabel,
      },
      scheduledDay: validDay,
      callRound: round,
      callRoundLabel: roundLabel,
      turnNumber,
      timeSlot,
    });
  };

  // 2. Schedule Critical Tier: 3 rounds across the business days in the window.
  criticalTier.forEach((client, i) => {
    const dayR1 = businessDays[i % firstRoundEnd];
    addSlot(dayR1, client, 1, '1ª Llamada (Corte Inmediato)');
    const secondRoundLength = Math.max(1, secondRoundEnd - firstRoundEnd);
    const dayR2 = businessDays[firstRoundEnd + (i % secondRoundLength)];
    addSlot(dayR2, client, 2, '2ª Llamada (Seguimiento Urgente)');
    const thirdRoundLength = Math.max(1, businessDays.length - secondRoundEnd);
    const dayR3 = businessDays[secondRoundEnd + (i % thirdRoundLength)];
    addSlot(dayR3, client, 3, '3ª Llamada (Cierre / Pre-Legal)');
  });

  // 3. Schedule Moderate Tier: 2 rounds across the business-day halves of the window.
  moderateTier.forEach((client, i) => {
    const dayR1 = businessDays[i % moderateRoundEnd];
    addSlot(dayR1, client, 1, '1ª Llamada (Gestión Preventiva)');

    const secondRoundLength = Math.max(1, businessDays.length - moderateRoundEnd);
    const dayR2 = businessDays[moderateRoundEnd + (i % secondRoundLength)];
    addSlot(dayR2, client, 2, '2ª Llamada (Verificación de Pago)');
  });

  // 4. Schedule Normal Tier (0-30 days / Factura del Mes): 1 to 2 Rounds
  normalTier.forEach((client, i) => {
    const firstRoundIndex = i % businessDays.length;
    const dayR1 = businessDays[firstRoundIndex];
    addSlot(dayR1, client, 1, '1ª Llamada (Recordatorio de Factura)');

    // For clients with larger billing in 0-30, add a second follow-up before day 21
    if ((client.totalDebt || 0) > 200 || i % 2 === 0) {
      const followUpIndex = firstRoundIndex + Math.ceil(businessDays.length / 3);
      if (followUpIndex < businessDays.length) {
        const dayR2 = businessDays[followUpIndex];
        addSlot(dayR2, client, 2, '2ª Llamada (Confirmación de Pago)');
      }
    }
  });

  // 5. Balance to target `clientsPerDay` (default 40) per day
  // If some days have less than `clientsPerDay`, repeat high-value pending clients for extra follow-up
  const moraRank: Record<string, number> = {
    '120+': 5,
    '91-120': 4,
    '61-90': 3,
    '31-60': 2,
    '0-30': 1,
  };
  const allScheduledClients = [...criticalTier, ...moderateTier, ...normalTier].sort(
    (a, b) =>
      (moraRank[b.moraRange] || 0) - (moraRank[a.moraRange] || 0) ||
      b.daysArrears - a.daysArrears ||
      (b.totalDebt || 0) - (a.totalDebt || 0) ||
      a.code.trim().toUpperCase().localeCompare(b.code.trim().toUpperCase()),
  );
  for (const d of businessDays) {
    let currentSlots = schedule[d];
    const alreadyScheduledToday = new Set(currentSlots.map((slot) => slot.client.code));
    const followUpCandidates = allScheduledClients.filter(
      (client) => !alreadyScheduledToday.has(client.code),
    );
    while (currentSlots.length < clientsPerDay && followUpCandidates.length > 0) {
      const client = followUpCandidates.shift()!;
      const previousCalls = Object.entries(schedule)
        .filter(([scheduledDay]) => Number(scheduledDay) < d)
        .flatMap(([, slots]) => slots)
        .filter((slot) => slot.client.code === client.code).length;

      if (previousCalls === 0) {
        // If this client had a first call later in the plan, move that first call here
        // instead of creating two first calls for the same month.
        for (let futureDay = d + 1; futureDay <= OPERATIONAL_DAYS_MAX; futureDay++) {
          schedule[futureDay] = schedule[futureDay].filter(
            (slot) => slot.client.code !== client.code || slot.callRound !== 1,
          );
        }
        addSlot(d, client, 1, '1ª Llamada (Primera gestión)');
      } else {
        const followUpRound = previousCalls + 1;
        const label = followUpRound === 2
          ? '2ª Llamada (Seguimiento por mora)'
          : `${followUpRound}ª Llamada (Seguimiento por mora)`;
        addSlot(d, client, followUpRound, label);
      }
      alreadyScheduledToday.add(client.code);
    }

    // If day has more than `clientsPerDay` (e.g. due to heavy concentration), trim or move excess
    if (currentSlots.length > clientsPerDay) {
      const excess = currentSlots.splice(clientsPerDay);
      excess.forEach((slot) => {
        const nextBusinessDay = businessDays.find((businessDay) => businessDay > d);
        if (nextBusinessDay) {
          addSlot(nextBusinessDay, slot.client, slot.callRound, slot.callRoundLabel);
        }
      });
    }

    // Re-index turn numbers for the day
    schedule[d] = schedule[d].slice(0, clientsPerDay).map((slot, idx) => ({
      ...slot,
      turnNumber: idx + 1,
      timeSlot: BUSINESS_HOURS_SLOTS[idx % BUSINESS_HOURS_SLOTS.length],
    }));
  }

  return schedule;
}

/**
 * Reschedules a client call to `targetDay` (1 to 21), maintaining strict cap of `clientsPerDay`
 * by gracefully displacing the lowest urgency call to the following day (up to day 21).
 */
export function rescheduleClientInSchedule(
  currentSchedule: Record<number, ScheduledCallSlot[]>,
  client: Client,
  targetDay: number,
  clientsPerDay: number = 40,
  reason = 'Reprogramado por Agente / IA'
): Record<number, ScheduledCallSlot[]> {
  const newSchedule: Record<number, ScheduledCallSlot[]> = {};
  for (let d = 1; d <= OPERATIONAL_DAYS_MAX; d++) {
    newSchedule[d] = [...(currentSchedule[d] || [])];
  }

  const validTarget = Math.min(Math.max(1, targetDay), OPERATIONAL_DAYS_MAX);

  // Create new slot
  const existingClientSlots = newSchedule[validTarget].filter((s) => s.client.code === client.code);
  const nextRound = existingClientSlots.length + 1;
  const newSlot: ScheduledCallSlot = {
    client: {
      ...client,
      scheduledDay: validTarget,
      callRound: nextRound,
      callRoundLabel: `${nextRound}ª Llamada (${reason})`,
    },
    scheduledDay: validTarget,
    callRound: nextRound,
    callRoundLabel: `${nextRound}ª Llamada (${reason})`,
    turnNumber: 1, // will be re-indexed
    timeSlot: BUSINESS_HOURS_SLOTS[0],
  };

  // Insert at top of target day (priority)
  newSchedule[validTarget].unshift(newSlot);

  // Propagate displacements if any day exceeds `clientsPerDay`
  for (let d = validTarget; d <= OPERATIONAL_DAYS_MAX; d++) {
    if (newSchedule[d].length > clientsPerDay) {
      const displaced = newSchedule[d].pop(); // remove lowest priority from end of day
      if (displaced && d < OPERATIONAL_DAYS_MAX) {
        displaced.scheduledDay = d + 1;
        displaced.client.scheduledDay = d + 1;
        newSchedule[d + 1].push(displaced);
      }
    }

    // Re-index turns for day d
    newSchedule[d] = newSchedule[d].map((slot, idx) => ({
      ...slot,
      turnNumber: idx + 1,
      timeSlot: BUSINESS_HOURS_SLOTS[idx % BUSINESS_HOURS_SLOTS.length],
    }));
  }

  return newSchedule;
}
